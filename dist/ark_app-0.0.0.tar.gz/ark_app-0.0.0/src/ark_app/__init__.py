"""Initialization module for the ark_app package"""
from ark_app.main import main